# SLR Digital Safe Work Permit

A local, responsive web app that turns the SLR Safe Work Permit paper form into an approval-controlled digital workflow.

## What it does

- A person must request access with their employee ID, department, and password.
- Only the administrator can approve or reject access requests.
- Approved users can submit safe work permits for MBF 1, MBF 2, Sinter 1, Sinter 2, SMS, CCM, and Rolling Mill.
- Each permit captures the key isolation, electrical, and general safety precautions from the paper form.
- Only the administrator can issue/reject permits and close them after job completion.
- Every key action is kept in the permit's audit trail.

## Run it on a Windows computer

1. Install [Python 3.11 or later](https://www.python.org/downloads/) and select **Add Python to PATH** during installation.
2. Open PowerShell in this folder.
3. Optional but recommended: set your own first administrator password for this run:

   ```powershell
   $env:INITIAL_ADMIN_PASSWORD = "Choose-a-strong-password"
   ```

4. Configure an SMS provider before running the page if you want OTPs to reach real mobile numbers:

   ```powershell
   $env:SMS_WEBHOOK_URL = "https://your-sms-provider.example/send"
   # or, for Twilio:
   $env:TWILIO_ACCOUNT_SID = "your-account-sid"
   $env:TWILIO_AUTH_TOKEN = "your-auth-token"
   $env:TWILIO_FROM_NUMBER = "+1234567890"
   ```

   The app now attempts a real SMS send through either a webhook or Twilio. Without those variables, the OTP request will fail with a 503 response instead of pretending the mobile message was delivered.

5. Start the app by double-clicking `start_app.bat`, or use:

   ```powershell
   python server.py
   ```

5. Open `http://127.0.0.1:8081` in a browser.

The first account is:

- Employee ID: `ADMIN-001`
- Password: `ChangeMe!2026` (unless you set `INITIAL_ADMIN_PASSWORD` before the first run)

Use that account only to approve employee access and permits. Immediately select **Change password** after signing in and replace the supplied default; for a real company rollout, use company authentication, HTTPS, secure backups, and a reviewed e-signature policy.

## Data location and backup

All app data is stored in `data/work_permit.db`. Back up this file while the server is stopped. Do not put it in public cloud sharing folders or send it through unencrypted email.

## Workflow

`Access request → Administrator approval → Permit submitted → Administrator issues → Job completed → Administrator closes`

This initial version is ideal as a pilot in MBF 1. Before live safety use, have your Safety, Operations, Mechanical, and Electrical authorities validate every checklist and approval requirement against your company procedure.
