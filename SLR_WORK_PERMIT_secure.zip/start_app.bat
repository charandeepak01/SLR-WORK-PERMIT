@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  py server.py
) else (
  python server.py
)

if errorlevel 1 (
  echo.
  echo Python 3 is required to start this app.
  echo Install Python from https://www.python.org/downloads/ and select "Add Python to PATH".
  pause
)
