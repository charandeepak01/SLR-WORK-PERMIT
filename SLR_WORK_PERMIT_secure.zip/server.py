"""SLR Digital Safe Work Permit - local, self-contained application.

Run with a standard Python 3 installation:
    python server.py

The application is intentionally dependency-free.  It stores data in
data/work_permit.db, which is created on first run.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.parse import urlencode, urlparse


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "work_permit.db"
STATIC_DIR = ROOT / "static"
HOST = "127.0.0.1"
PORT = int(os.environ.get("PORT", "8081"))

DEPARTMENTS = ["Mechanical", "Operation", "Safety", "Electrician", "Fire Department"]
DIVISIONS = ["MBF 1", "MBF 2", "Sinter 1", "Sinter 2", "SMS", "CCM", "Rolling Mill"]
ROLES = ["requester", "issuer", "safety", "admin"]
PERMIT_STATUSES = ["pending_approval", "issued", "job_completed", "closed", "rejected"]

# In-memory sessions are deliberately short-lived and disappear when the server stops.
SESSIONS: dict[str, dict[str, Any]] = {}


def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def password_hash(password: str, salt: str | None = None) -> tuple[str, str]:
    if salt is None:
        salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), 210_000)
    return salt, digest.hex()


def send_sms(number: str, message: str) -> bool:
    twilio_account_sid = os.environ.get("TWILIO_ACCOUNT_SID", "").strip()
    twilio_auth_token = os.environ.get("TWILIO_AUTH_TOKEN", "").strip()
    twilio_from_number = os.environ.get("TWILIO_FROM_NUMBER", "").strip()
    webhook_url = os.environ.get("SMS_WEBHOOK_URL", "").strip()

    if twilio_account_sid and twilio_auth_token and twilio_from_number:
        try:
            payload = urlencode({"To": number, "From": twilio_from_number, "Body": message}).encode("utf-8")
            request = __import__("urllib.request").request.Request(
                f"https://api.twilio.com/2010-04-01/Accounts/{twilio_account_sid}/Messages.json",
                data=payload,
                method="POST",
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            auth_value = base64.b64encode(f"{twilio_account_sid}:{twilio_auth_token}".encode("utf-8")).decode("ascii")
            request.add_header("Authorization", f"Basic {auth_value}")
            with __import__("urllib.request").request.urlopen(request, timeout=10) as response:
                return response.status < 400
        except Exception as exc:
            print(f"[SMS ERROR] Twilio delivery failed: {exc}")
            return False

    if webhook_url:
        try:
            payload = json.dumps({"to": number, "message": message}).encode("utf-8")
            request = __import__("urllib.request").request.Request(webhook_url, data=payload, method="POST", headers={"Content-Type": "application/json"})
            with __import__("urllib.request").request.urlopen(request, timeout=10) as response:
                return response.status < 400
        except Exception as exc:
            print(f"[SMS ERROR] Webhook delivery failed: {exc}")
            return False

    print(f"[SMS DEMO] To {number}: {message}")
    return False


def audit(conn: sqlite3.Connection, actor_id: int | None, action: str, entity_type: str, entity_id: int | None, detail: dict[str, Any] | None = None) -> None:
    conn.execute(
        "INSERT INTO audit_logs (actor_id, action, entity_type, entity_id, detail, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (actor_id, action, entity_type, entity_id, json.dumps(detail or {}), now()),
    )


def init_db() -> None:
    DATA_DIR.mkdir(exist_ok=True)
    conn = db()
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            employee_id TEXT NOT NULL UNIQUE COLLATE NOCASE,
            division TEXT NOT NULL DEFAULT 'MBF 1',
            department TEXT NOT NULL,
            mobile_number TEXT NOT NULL DEFAULT '',
            role TEXT NOT NULL DEFAULT 'requester',
            password_salt TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            approval_status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL,
            approved_at TEXT,
            approved_by INTEGER,
            FOREIGN KEY (approved_by) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS permits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            permit_no TEXT NOT NULL UNIQUE,
            work_description TEXT NOT NULL,
            division TEXT NOT NULL,
            department TEXT NOT NULL,
            area TEXT NOT NULL,
            equipment TEXT,
            contact_number TEXT NOT NULL DEFAULT '',
            requester_id INTEGER NOT NULL,
            requested_at TEXT NOT NULL,
            valid_from TEXT NOT NULL,
            valid_until TEXT NOT NULL,
            job_types TEXT NOT NULL,
            isolations TEXT NOT NULL,
            precautions TEXT NOT NULL,
            electrical TEXT NOT NULL,
            normalisation TEXT NOT NULL DEFAULT '{}',
            status TEXT NOT NULL DEFAULT 'pending_approval',
            issuer_note TEXT,
            issued_by INTEGER,
            issued_at TEXT,
            completed_by INTEGER,
            completed_at TEXT,
            closed_by INTEGER,
            closed_at TEXT,
            FOREIGN KEY (requester_id) REFERENCES users(id),
            FOREIGN KEY (issued_by) REFERENCES users(id),
            FOREIGN KEY (completed_by) REFERENCES users(id),
            FOREIGN KEY (closed_by) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor_id INTEGER,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id INTEGER,
            detail TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL,
            FOREIGN KEY (actor_id) REFERENCES users(id)
        );
        """
    )
    user_columns = {row[1] for row in conn.execute("PRAGMA table_info(users)").fetchall()}
    if "division" not in user_columns:
        conn.execute("ALTER TABLE users ADD COLUMN division TEXT NOT NULL DEFAULT 'MBF 1'")
    if "mobile_number" not in user_columns:
        conn.execute("ALTER TABLE users ADD COLUMN mobile_number TEXT NOT NULL DEFAULT ''")

    permit_columns = {row[1] for row in conn.execute("PRAGMA table_info(permits)").fetchall()}
    if "contact_number" not in permit_columns:
        conn.execute("ALTER TABLE permits ADD COLUMN contact_number TEXT NOT NULL DEFAULT ''")

    existing = conn.execute("SELECT id FROM users WHERE role = 'admin' LIMIT 1").fetchone()
    if not existing:
        initial_password = os.environ.get("INITIAL_ADMIN_PASSWORD", "ChangeMe!2026")
        salt, digest = password_hash(initial_password)
        conn.execute(
            """INSERT INTO users (full_name, employee_id, division, department, role, password_salt, password_hash,
               approval_status, created_at, approved_at) VALUES (?, ?, ?, ?, 'admin', ?, ?, 'approved', ?, ?)""",
            ("System Administrator", "ADMIN-001", "MBF 1", "Safety", salt, digest, now(), now()),
        )
        audit(conn, 1, "Initial administrator created", "user", 1, {"employee_id": "ADMIN-001"})
    conn.commit()
    conn.close()


def public_user(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "fullName": row["full_name"],
        "employeeId": row["employee_id"],
        "division": row["division"],
        "department": row["department"],
        "mobileNumber": row["mobile_number"],
        "role": row["role"],
        "approvalStatus": row["approval_status"],
        "createdAt": row["created_at"],
        "approvedAt": row["approved_at"],
    }


def permit_dict(row: sqlite3.Row, include_details: bool = False) -> dict[str, Any]:
    result = {
        "id": row["id"],
        "permitNo": row["permit_no"],
        "workDescription": row["work_description"],
        "division": row["division"],
        "department": row["department"],
        "area": row["area"],
        "equipment": row["equipment"],
        "contactNumber": row["contact_number"],
        "requesterId": row["requester_id"],
        "requesterName": row["requester_name"],
        "requestedAt": row["requested_at"],
        "validFrom": row["valid_from"],
        "validUntil": row["valid_until"],
        "status": row["status"],
        "issuerNote": row["issuer_note"],
        "issuedByName": row["issued_by_name"],
        "issuedAt": row["issued_at"],
        "completedByName": row["completed_by_name"],
        "completedAt": row["completed_at"],
        "closedByName": row["closed_by_name"],
        "closedAt": row["closed_at"],
    }
    if include_details:
        result.update({
            "jobTypes": json.loads(row["job_types"]),
            "isolations": json.loads(row["isolations"]),
            "precautions": json.loads(row["precautions"]),
            "electrical": json.loads(row["electrical"]),
            "normalisation": json.loads(row["normalisation"]),
        })
    return result


PERMIT_SELECT = """
    SELECT p.*, requester.full_name AS requester_name, issuer.full_name AS issued_by_name,
           completer.full_name AS completed_by_name, closer.full_name AS closed_by_name
    FROM permits p
    JOIN users requester ON requester.id = p.requester_id
    LEFT JOIN users issuer ON issuer.id = p.issued_by
    LEFT JOIN users completer ON completer.id = p.completed_by
    LEFT JOIN users closer ON closer.id = p.closed_by
"""


class AppError(Exception):
    def __init__(self, message: str, status: int = HTTPStatus.BAD_REQUEST):
        super().__init__(message)
        self.status = status


class PermitHandler(BaseHTTPRequestHandler):
    server_version = "SLRPermit/1.0"

    def log_message(self, format: str, *args: Any) -> None:
        # Keep normal browser requests out of the console; errors remain visible.
        return

    def send_json(self, payload: dict[str, Any] | list[Any], status: int = HTTPStatus.OK) -> None:
        body = json.dumps(payload, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > 1_000_000:
            raise AppError("Invalid request body.")
        try:
            value = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise AppError("Request body must be valid JSON.") from exc
        if not isinstance(value, dict):
            raise AppError("Request body must be an object.")
        return value

    def current_user(self, required: bool = True) -> sqlite3.Row | None:
        auth = self.headers.get("Authorization", "")
        token = auth.removeprefix("Bearer ").strip() if auth.startswith("Bearer ") else ""
        session = SESSIONS.get(token)
        if not session or session["expires"] < datetime.now(timezone.utc):
            if token:
                SESSIONS.pop(token, None)
            if required:
                raise AppError("Please sign in to continue.", HTTPStatus.UNAUTHORIZED)
            return None
        conn = db()
        try:
            row = conn.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
        finally:
            conn.close()
        if not row or row["approval_status"] != "approved":
            SESSIONS.pop(token, None)
            raise AppError("Your account is no longer approved.", HTTPStatus.UNAUTHORIZED)
        return row

    @staticmethod
    def require_admin(user: sqlite3.Row) -> None:
        if user["role"] != "admin":
            raise AppError("Only the administrator can approve this action.", HTTPStatus.FORBIDDEN)

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Allow", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        try:
            if path.startswith("/api/"):
                self.api_get(path)
            else:
                self.static_get(path)
        except AppError as exc:
            self.send_json({"error": str(exc)}, exc.status)
        except Exception:
            self.send_json({"error": "An unexpected server error occurred."}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            if not path.startswith("/api/"):
                raise AppError("Not found.", HTTPStatus.NOT_FOUND)
            self.api_post(path)
        except AppError as exc:
            self.send_json({"error": str(exc)}, exc.status)
        except Exception:
            self.send_json({"error": "An unexpected server error occurred."}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def static_get(self, path: str) -> None:
        file_name = "index.html" if path in ("/", "") else path.lstrip("/")
        if file_name not in {"index.html", "styles.css", "app.js", "assets/slr-metaliks-logo.png", "assets/slr-app-icon.svg"}:
            raise AppError("Not found.", HTTPStatus.NOT_FOUND)
        file_path = STATIC_DIR / file_name
        if not file_path.is_file():
            raise AppError("Application files are missing.", HTTPStatus.INTERNAL_SERVER_ERROR)
        content_type = {
            "index.html": "text/html; charset=utf-8",
            "styles.css": "text/css; charset=utf-8",
            "app.js": "application/javascript; charset=utf-8",
            "assets/slr-metaliks-logo.png": "image/png",
            "assets/slr-app-icon.svg": "image/svg+xml",
        }[file_name]
        body = file_path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)

    def api_get(self, path: str) -> None:
        if path == "/api/health":
            self.send_json({"ok": True, "time": now()})
            return
        if path == "/api/config":
            self.send_json({"departments": DEPARTMENTS, "divisions": DIVISIONS})
            return
        if path == "/api/auth/me":
            user = self.current_user()
            self.send_json({"user": public_user(user)})
            return
        if path == "/api/dashboard":
            user = self.current_user()
            conn = db()
            try:
                permit_filter = "" if user["role"] == "admin" else " WHERE requester_id = ?"
                params: tuple[Any, ...] = () if user["role"] == "admin" else (user["id"],)
                status_rows = conn.execute(f"SELECT status, COUNT(*) AS count FROM permits{permit_filter} GROUP BY status", params).fetchall()
                recent = conn.execute(PERMIT_SELECT + ("" if user["role"] == "admin" else " WHERE p.requester_id = ?") + " ORDER BY p.id DESC LIMIT 6", params).fetchall()
                pending_users = conn.execute("SELECT COUNT(*) AS count FROM users WHERE approval_status = 'pending'").fetchone()["count"] if user["role"] == "admin" else 0
            finally:
                conn.close()
            self.send_json({"counts": {r["status"]: r["count"] for r in status_rows}, "pendingUsers": pending_users, "recent": [permit_dict(r) for r in recent]})
            return
        if path == "/api/users/pending":
            user = self.current_user()
            self.require_admin(user)
            conn = db()
            try:
                rows = conn.execute("SELECT * FROM users WHERE approval_status = 'pending' ORDER BY created_at ASC").fetchall()
            finally:
                conn.close()
            self.send_json({"users": [public_user(r) for r in rows]})
            return
        if path == "/api/permits":
            user = self.current_user()
            conn = db()
            try:
                if user["role"] == "admin":
                    rows = conn.execute(PERMIT_SELECT + " ORDER BY p.id DESC").fetchall()
                else:
                    rows = conn.execute(PERMIT_SELECT + " WHERE p.requester_id = ? ORDER BY p.id DESC", (user["id"],)).fetchall()
            finally:
                conn.close()
            self.send_json({"permits": [permit_dict(r) for r in rows]})
            return
        if path.startswith("/api/permits/"):
            permit_id = self.path_id(path, "/api/permits/")
            user = self.current_user()
            conn = db()
            try:
                row = conn.execute(PERMIT_SELECT + " WHERE p.id = ?", (permit_id,)).fetchone()
                if not row:
                    raise AppError("Permit not found.", HTTPStatus.NOT_FOUND)
                if user["role"] != "admin" and row["requester_id"] != user["id"]:
                    raise AppError("You cannot view this permit.", HTTPStatus.FORBIDDEN)
                audit_rows = conn.execute(
                    """SELECT a.*, u.full_name AS actor_name FROM audit_logs a
                       LEFT JOIN users u ON u.id = a.actor_id
                       WHERE a.entity_type = 'permit' AND a.entity_id = ? ORDER BY a.id ASC""", (permit_id,)
                ).fetchall()
            finally:
                conn.close()
            self.send_json({"permit": permit_dict(row, True), "audit": [{"action": a["action"], "actor": a["actor_name"] or "System", "createdAt": a["created_at"], "detail": json.loads(a["detail"])} for a in audit_rows]})
            return
        raise AppError("Not found.", HTTPStatus.NOT_FOUND)

    def api_post(self, path: str) -> None:
        if path == "/api/auth/register":
            self.register()
            return
        if path == "/api/auth/login":
            self.login()
            return
        if path == "/api/auth/logout":
            auth = self.headers.get("Authorization", "")
            SESSIONS.pop(auth.removeprefix("Bearer ").strip(), None)
            self.send_json({"ok": True})
            return
        if path == "/api/auth/change-password":
            self.change_password()
            return
        if path == "/api/permits":
            self.create_permit()
            return
        if path.startswith("/api/users/") and path.endswith("/approve"):
            self.approve_user(self.path_id(path, "/api/users/", "/approve"))
            return
        if path.startswith("/api/users/") and path.endswith("/reject"):
            self.reject_user(self.path_id(path, "/api/users/", "/reject"))
            return
        if path.startswith("/api/permits/") and path.endswith("/issue"):
            self.issue_permit(self.path_id(path, "/api/permits/", "/issue"))
            return
        if path.startswith("/api/permits/") and path.endswith("/complete"):
            self.complete_permit(self.path_id(path, "/api/permits/", "/complete"))
            return
        if path.startswith("/api/permits/") and path.endswith("/close"):
            self.close_permit(self.path_id(path, "/api/permits/", "/close"))
            return
        raise AppError("Not found.", HTTPStatus.NOT_FOUND)

    @staticmethod
    def path_id(path: str, prefix: str, suffix: str = "") -> int:
        raw = path[len(prefix):len(path) - len(suffix) if suffix else None]
        if not raw.isdigit():
            raise AppError("Invalid record identifier.", HTTPStatus.NOT_FOUND)
        return int(raw)

    def register(self) -> None:
        data = self.read_json()
        full_name = str(data.get("fullName", "")).strip()
        employee_id = str(data.get("employeeId", "")).strip().upper()
        division = str(data.get("division", "")).strip()
        department = str(data.get("department", "")).strip()
        mobile_number = str(data.get("mobileNumber", "")).strip()
        password = str(data.get("password", ""))
        if len(full_name) < 2 or len(full_name) > 100:
            raise AppError("Enter your full name (2–100 characters).")
        if len(employee_id) < 2 or len(employee_id) > 40:
            raise AppError("Enter a valid employee ID.")
        if division not in DIVISIONS:
            raise AppError("Choose a valid division.")
        if department not in DEPARTMENTS:
            raise AppError("Choose a valid department.")
        if not re.fullmatch(r"[+()\-\d\s]{8,20}", mobile_number):
            raise AppError("Enter a valid mobile number.")
        if len(password) < 8 or len(password) > 200:
            raise AppError("Password must be at least 8 characters.")
        salt, digest = password_hash(password)
        conn = db()
        try:
            cursor = conn.execute(
                """INSERT INTO users (full_name, employee_id, division, department, mobile_number, role, password_salt, password_hash, approval_status, created_at)
                   VALUES (?, ?, ?, ?, ?, 'requester', ?, ?, 'pending', ?)""",
                (full_name, employee_id, division, department, mobile_number, salt, digest, now()),
            )
            audit(conn, cursor.lastrowid, "Access requested", "user", cursor.lastrowid, {"division": division, "department": department, "mobile_number": mobile_number})
            conn.commit()
        except sqlite3.IntegrityError:
            raise AppError("This employee ID already has an account.", HTTPStatus.CONFLICT)
        finally:
            conn.close()
        self.send_json({"message": "Your access request was sent to the administrator. You can sign in after approval."}, HTTPStatus.CREATED)

    def login(self) -> None:
        data = self.read_json()
        employee_id = str(data.get("employeeId", "")).strip().upper()
        password = str(data.get("password", ""))
        conn = db()
        try:
            user = conn.execute("SELECT * FROM users WHERE employee_id = ?", (employee_id,)).fetchone()
        finally:
            conn.close()
        if not user:
            raise AppError("Employee ID or password is incorrect.", HTTPStatus.UNAUTHORIZED)
        _, digest = password_hash(password, user["password_salt"])
        if not secrets.compare_digest(digest, user["password_hash"]):
            raise AppError("Employee ID or password is incorrect.", HTTPStatus.UNAUTHORIZED)
        if user["approval_status"] == "pending":
            raise AppError("Your access request is awaiting administrator approval.", HTTPStatus.FORBIDDEN)
        if user["approval_status"] != "approved":
            raise AppError("Your account request was not approved. Contact the administrator.", HTTPStatus.FORBIDDEN)
        token = secrets.token_urlsafe(32)
        SESSIONS[token] = {"user_id": user["id"], "expires": datetime.now(timezone.utc) + timedelta(hours=12)}
        self.send_json({"token": token, "user": public_user(user)})

    def change_password(self) -> None:
        user = self.current_user()
        data = self.read_json()
        current_password = str(data.get("currentPassword", ""))
        new_password = str(data.get("newPassword", ""))
        if len(new_password) < 12 or len(new_password) > 200:
            raise AppError("New password must be 12–200 characters.")
        _, current_digest = password_hash(current_password, user["password_salt"])
        if not secrets.compare_digest(current_digest, user["password_hash"]):
            raise AppError("Current password is incorrect.", HTTPStatus.UNAUTHORIZED)
        salt, digest = password_hash(new_password)
        conn = db()
        try:
            conn.execute("UPDATE users SET password_salt = ?, password_hash = ? WHERE id = ?", (salt, digest, user["id"]))
            audit(conn, user["id"], "Password changed", "user", user["id"])
            conn.commit()
        finally:
            conn.close()
        self.send_json({"message": "Password changed successfully."})

    def approve_user(self, user_id: int) -> None:
        admin = self.current_user()
        self.require_admin(admin)
        data = self.read_json()
        role = str(data.get("role", "requester"))
        if role not in ROLES:
            raise AppError("Invalid role.")
        conn = db()
        try:
            target = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
            if not target or target["approval_status"] != "pending":
                raise AppError("This access request is no longer pending.", HTTPStatus.NOT_FOUND)
            conn.execute("UPDATE users SET approval_status = 'approved', role = ?, approved_by = ?, approved_at = ? WHERE id = ?", (role, admin["id"], now(), user_id))
            audit(conn, admin["id"], "Access approved", "user", user_id, {"role": role})
            conn.commit()
        finally:
            conn.close()
        send_sms(target["mobile_number"], "Congrats! You are approved for work permit in SLR.")
        self.send_json({"message": "User approved."})

    def reject_user(self, user_id: int) -> None:
        admin = self.current_user()
        self.require_admin(admin)
        conn = db()
        try:
            target = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
            if not target or target["approval_status"] != "pending":
                raise AppError("This access request is no longer pending.", HTTPStatus.NOT_FOUND)
            conn.execute("UPDATE users SET approval_status = 'rejected', approved_by = ?, approved_at = ? WHERE id = ?", (admin["id"], now(), user_id))
            audit(conn, admin["id"], "Access rejected", "user", user_id)
            conn.commit()
        finally:
            conn.close()
        self.send_json({"message": "Access request rejected."})

    def create_permit(self) -> None:
        user = self.current_user()
        data = self.read_json()
        description = str(data.get("workDescription", "")).strip()
        division = str(data.get("division", "")).strip()
        department = str(user.get("department") or data.get("department", "")).strip()
        area = str(data.get("area", "")).strip()
        equipment = str(data.get("equipment", "")).strip()
        contact_number = str(data.get("contactNumber", "")).strip()
        valid_from = str(data.get("validFrom", "")).strip()
        valid_until = str(data.get("validUntil", "")).strip()
        job_types = data.get("jobTypes", [])
        isolations = data.get("isolations", {})
        precautions = data.get("precautions", {})
        electrical = data.get("electrical", {})
        if len(description) < 5 or len(description) > 2000:
            raise AppError("Work description must be 5–2000 characters.")
        if division not in DIVISIONS or department not in DEPARTMENTS or not area:
            raise AppError("Complete division, department, and area/location.")
        if not re.fullmatch(r"[+()\-\d\s]{8,20}", contact_number):
            raise AppError("Enter a valid mobile number for contact.")
        if len(area) > 200 or len(equipment) > 200:
            raise AppError("Area and equipment entries are too long.")
        if not isinstance(job_types, list) or not all(isinstance(x, str) for x in job_types):
            raise AppError("Invalid job types.")
        if not all(isinstance(x, dict) for x in (isolations, precautions, electrical)):
            raise AppError("Invalid safety checklist.")
        try:
            starts = datetime.fromisoformat(valid_from.replace("Z", "+00:00"))
            ends = datetime.fromisoformat(valid_until.replace("Z", "+00:00"))
            if ends <= starts:
                raise ValueError
        except ValueError:
            raise AppError("Permit end time must be later than the start time.")
        conn = db()
        try:
            seq = conn.execute("SELECT COUNT(*) AS count FROM permits WHERE substr(requested_at, 1, 10) = ?", (now()[:10],)).fetchone()["count"] + 1
            permit_no = f"SWP-{datetime.now().strftime('%Y%m%d')}-{seq:03d}"
            cursor = conn.execute(
                """INSERT INTO permits (permit_no, work_description, division, department, area, equipment, contact_number, requester_id,
                   requested_at, valid_from, valid_until, job_types, isolations, precautions, electrical, status)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending_approval')""",
                (permit_no, description, division, department, area, equipment, contact_number, user["id"], now(), valid_from, valid_until,
                 json.dumps(job_types), json.dumps(isolations), json.dumps(precautions), json.dumps(electrical)),
            )
            audit(conn, user["id"], "Permit submitted for approval", "permit", cursor.lastrowid, {"permit_no": permit_no, "contact_number": contact_number})
            conn.commit()
        finally:
            conn.close()
        self.send_json({"message": "Permit sent to the administrator for approval.", "permitId": cursor.lastrowid, "permitNo": permit_no}, HTTPStatus.CREATED)

    def permit_for_action(self, permit_id: int, allowed_status: str) -> tuple[sqlite3.Row, sqlite3.Connection]:
        conn = db()
        row = conn.execute(PERMIT_SELECT + " WHERE p.id = ?", (permit_id,)).fetchone()
        if not row:
            conn.close()
            raise AppError("Permit not found.", HTTPStatus.NOT_FOUND)
        if row["status"] != allowed_status:
            conn.close()
            raise AppError("This permit is not in the required workflow stage.")
        return row, conn

    def issue_permit(self, permit_id: int) -> None:
        admin = self.current_user()
        self.require_admin(admin)
        data = self.read_json()
        decision = str(data.get("decision", "approve"))
        note = str(data.get("note", "")).strip()[:1000]
        if decision not in {"approve", "reject"}:
            raise AppError("Invalid approval decision.")
        row, conn = self.permit_for_action(permit_id, "pending_approval")
        try:
            if decision == "approve":
                conn.execute("UPDATE permits SET status = 'issued', issuer_note = ?, issued_by = ?, issued_at = ? WHERE id = ?", (note, admin["id"], now(), permit_id))
                action = "Permit issued by administrator"
                message = "Permit issued."
            else:
                conn.execute("UPDATE permits SET status = 'rejected', issuer_note = ?, issued_by = ?, issued_at = ? WHERE id = ?", (note, admin["id"], now(), permit_id))
                action = "Permit rejected by administrator"
                message = "Permit rejected."
            audit(conn, admin["id"], action, "permit", permit_id, {"note": note, "permit_no": row["permit_no"]})
            conn.commit()
        finally:
            conn.close()
        self.send_json({"message": message})

    def complete_permit(self, permit_id: int) -> None:
        user = self.current_user()
        row, conn = self.permit_for_action(permit_id, "issued")
        try:
            if user["role"] != "admin" and row["requester_id"] != user["id"]:
                raise AppError("Only the requesting person can mark this job complete.", HTTPStatus.FORBIDDEN)
            data = self.read_json()
            normalisation = data.get("normalisation", {})
            if not isinstance(normalisation, dict):
                raise AppError("Invalid normalisation checklist.")
            conn.execute("UPDATE permits SET status = 'job_completed', normalisation = ?, completed_by = ?, completed_at = ? WHERE id = ?", (json.dumps(normalisation), user["id"], now(), permit_id))
            audit(conn, user["id"], "Job completion submitted", "permit", permit_id)
            conn.commit()
        finally:
            conn.close()
        self.send_json({"message": "Job completion sent to the administrator for closure."})

    def close_permit(self, permit_id: int) -> None:
        admin = self.current_user()
        self.require_admin(admin)
        row, conn = self.permit_for_action(permit_id, "job_completed")
        try:
            conn.execute("UPDATE permits SET status = 'closed', closed_by = ?, closed_at = ? WHERE id = ?", (admin["id"], now(), permit_id))
            audit(conn, admin["id"], "Permit closed after normalisation review", "permit", permit_id, {"permit_no": row["permit_no"]})
            conn.commit()
        finally:
            conn.close()
        self.send_json({"message": "Permit closed."})


def main() -> None:
    init_db()
    server = ThreadingHTTPServer((HOST, PORT), PermitHandler)
    print(f"SLR Digital Safe Work Permit is running at http://{HOST}:{PORT}")
    print("Press Ctrl+C to stop the server.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
